package com.lumination.backrooms.mixin;

import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import net.minecraft.client.gui.screen.AddServerScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AddServerScreen.class)
public abstract class AddServerScreenMixin extends Screen {

    @Mutable
    @Shadow private ServerInfo server;

    @Shadow private TextFieldWidget serverNameField;

    @Shadow private TextFieldWidget addressField;

    @Shadow protected abstract void addAndClose();

    public AddServerScreenMixin() {
        super(Text.translatable("addServer.title"));
    }

    @Inject(at = @At("HEAD"), method = "init()V")
    public void init(CallbackInfo ci) {
        this.addDrawableChild(new ButtonWidget(this.width / 2 - 100, this.height / 4 + 144 + 18, 200, 20, Text.literal("Unknown SMP"), (button) -> {
            unknownSmp();
        }));
    }

    public void unknownSmp() {
        this.serverNameField.setText("Unknown SMP");
        this.addressField.setText("lumination.brebond.com");
        this.server.setResourcePackPolicy(ServerInfo.ResourcePackPolicy.ENABLED);
        this.addAndClose();
    }
}
