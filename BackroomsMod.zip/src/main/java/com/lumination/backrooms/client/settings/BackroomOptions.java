package com.lumination.backrooms.client.settings;

public class BackroomOptions {
    private ChangeableOption<Boolean> spawnEntities;

    public ChangeableOption<Boolean> getSpawnEntities() {
        return this.spawnEntities;
    }
}
