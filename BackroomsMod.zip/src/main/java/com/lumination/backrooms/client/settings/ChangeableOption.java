package com.lumination.backrooms.client.settings;

import com.lumination.backrooms.BackroomsMod;
import com.mojang.serialization.Codec;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.text.Text;

import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;

public class ChangeableOption<T> {
    private ChangeableOption.Callbacks callbacks;
    private Consumer<T> changeCallback;
    private Text text;
    private boolean isBool = false;
    private T[] choices;
    private T defaultValue;
    T value;

    public ChangeableOption(Text name, T defaultValue, T[] availableChoices, ChangeableOption.Callbacks<T> callbacks, Consumer<T> changeCallback) {
        this.text = name;
        this.callbacks = callbacks;
        this.changeCallback = changeCallback;
        this.defaultValue = defaultValue;
        this.choices = availableChoices;
        this.value = defaultValue;

        if (defaultValue instanceof Boolean) {
            this.isBool = true;
        }
    }

    /*setValue(T value) {

    }*/

    /**
     * This is Minecraft's "setValue" function
     * @param value The value you want to change T to
     */
    public void setValue(T value) {
        T object = (T) this.callbacks.validate(value).orElseGet(() -> {
            BackroomsMod.LOGGER.error("Illegal option value " + value + " for " + this.text);
            return this.defaultValue;
        });
        if (!MinecraftClient.getInstance().isRunning()) {
            this.value = object;
        } else {
            if (!Objects.equals(this.value, object)) {
                this.value = object;
                this.changeCallback.accept(this.value);
            }

        }
    }

    // other

    @Environment(EnvType.CLIENT)
    interface Callbacks<T> {
        Function<SimpleOption<T>, ClickableWidget> getButtonCreator(SimpleOption.TooltipFactory<T> tooltipFactory, GameOptions gameOptions, int x, int y, int width);

        Optional<T> validate(T value);

        Codec<T> codec();
    }
}
